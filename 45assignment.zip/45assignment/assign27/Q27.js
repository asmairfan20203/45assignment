"use strict";
// 27:Alien Colors #3: Turn your if-else chain from Exercise 5-4 into an if-else chain.
// • If the alien is green, print a message that the player earned 5 points.
// • If the alien is yellow, print a message that the player earned 10 points.
// • If the alien is red, print a message that the player earned 15 points.
// • Write three versions of this program, making sure each message is printed for the appropriate color alien.
// 1st version
let alien_color;
console.log("This is first version alien color is green");
alien_color = 'green';
if (alien_color == 'green') {
    console.log("Congratulation! you just earned 5 points");
}
else if (alien_color == 'yellow') {
    console.log("Congratulation! you just earned 10 points");
}
else if (alien_color == 'red') {
    console.log("Congratulation! you just earned 15 points");
}
else {
    console.log('Unknown alien color');
}
console.log("This is first version alien color is green");
// 2nd version
console.log("This is first version alien color is green");
alien_color = 'yellow';
if (alien_color == 'green') {
    console.log("Congratulation! you just earned 5 points");
}
else if (alien_color == 'yellow') {
    console.log("Congratulation! you just earned 10 points");
}
else if (alien_color == 'red') {
    console.log("Congratulation! you just earned 15 points");
}
else {
    console.log('Unknown alien color');
}
//   // 3rd version
console.log("This is first version alien color is green");
alien_color = 'red';
if (alien_color == 'green') {
    console.log("Congratulation! you just earned 5 points");
}
else if (alien_color == 'yellow') {
    console.log("Congratulation! you just earned 10 points");
    99;
}
else if (alien_color == 'red') {
    console.log("Congratulation! you just earned 15 points");
}
else {
    console.log('Unknown alien color');
}

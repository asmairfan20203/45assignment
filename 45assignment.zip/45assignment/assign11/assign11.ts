// 11.Names: Store the names of a few of your friends in a array called names. Print each person’s name by accessing each element in the list, one at a time.

let Name: string[]=["Eric","Jackson", "Tom crouse", "Micheal", "Dolly"];
console.log(Name[0]);
console.log(Name[1]);
console.log(Name[2]);
console.log(Name[3]);
console.log(Name[4]);


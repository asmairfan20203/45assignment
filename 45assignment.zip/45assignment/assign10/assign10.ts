// 10.Adding Comments: Choose two of the programs you’ve written, and add at least one comment to each. If you don’t have anything specific to write because your programs are too simple at this point, just add your name and the current date at the top of each program file. Then write one sentence describing what the program does.
// assignment # 8
// dated: 12th january, 2024
// make a function to sum of two numbers
 function sum(para1:number,para2:number){
   console.log(para1+para2);
 }
 sum(5,7);
 // Assignment # 10 
// dated 22/01/ 2024
function studentdata(Name1:string, myAge:number, rollnumber:number){
    console.log( `my name ${Name1},i am ${myAge} years old,my rollnumber is ${rollnumber}`);
}
studentdata("Asmairfan",25,119);  
studentdata("syedawarda",20,215);  
studentdata("saimaafzal",21,105); 



"use strict";
// 8.You should create four lines that look like this:
// console.log(5 + 3)
// Your output should simply be four lines with the number 8 appearing once on each line.
console.log(5 + 3);
console.log(15 - 7);
console.log(8 * 1);
console.log(56 / 7);

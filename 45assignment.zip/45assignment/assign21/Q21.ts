// 21. They think of something you could store in a TypeScript Object. Write a program that creates Objects containing these ite
let Pakistanies = ["Asma","Ali","Saba","Haya","Ahmad", "Fatima","Mustafa"];
for(let a=0; a<=6; a++){
    console.log(Pakistanies[a]);
}
let obj ={
    name:"Ahmad Mustafa",
    Age:"21 years",
    salary:"45,000",
    No: 27
}
console.log(obj);
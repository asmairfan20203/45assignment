// 20.Think of something you could store in a array. For example, you could make a list of mountains, rivers, countries, cities, languages, or anything else you’d like. Write a program that creates a list containing these items.
let Mountainl: string[] = ["K2", "Mount Everest", "Himaliya","Nanga Parbat"];
let Riversl: string[] = ["The River Indus", "The Chanab", "The Satlaj", "The Ravi","The Farat", "The Neil"];
let Countriesl: string[] = ["Pakistan","Saudia Ariba","Dubai", "France","Dubai","South Africa"];
let Citiesl: string[] = ["Karachi","Makkah","Madina","Sawat","Paris","Murry"];
let languagesl: string[] = ["Urdu","English","Arabic","Chinese","Hindhi", "Sindhi", "Pashto"];
console.log(`The list of Mountains is..... ${Mountainl}`);
console.log(`The list of Rivers is..... ${Riversl}`);
console.log(`The list of Countriess is..... ${Countriesl}`);
console.log(`The list of Cities is..... ${Citiesl}`);
console.log(`The list of languages is..... ${languagesl}`);
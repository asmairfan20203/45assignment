"use strict";
// 20.Think of something you could store in a array. For example, you could make a list of mountains, rivers, countries, cities, languages, or anything else you’d like. Write a program that creates a list containing these items.
let Mountainl = ["K2", "Mount Everest", "Himaliya", "Nanga Parbat"];
let Riversl = ["The River Indus", "The Chanab", "The Satlaj", "The Ravi", "The Farat", "The Neil"];
let Countriesl = ["Pakistan", "Saudia Ariba", "Dubai", "France", "Dubai", "South Africa"];
let Citiesl = ["Karachi", "Makkah", "Madina", "Sawat", "Paris", "Murry"];
let languagesl = ["Urdu", "English", "Arabic", "Chinese", "Hindhi", "Sindhi", "Pashto"];
console.log(`The list of Mountains is..... ${Mountainl}`);
console.log(`The list of Rivers is..... ${Riversl}`);
console.log(`The list of Countriess is..... ${Countriesl}`);
console.log(`The list of Cities is..... ${Citiesl}`);
console.log(`The list of languages is..... ${languagesl}`);

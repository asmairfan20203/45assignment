// 12.Greetings: Start with the array you used in Exercise 11, but instead of just printing each person’s name, print a message to them. The text of each message should be the same, but each message should be personalized with the person’s name.

// print a message with a person name
let Name2: string[]=["Eric","Jackson", "Tom crouse", "Micheal", "Dolly"];
console.log ( "How are YOU?", Name2[0] );
console.log ( "How are YOU?", Name2[1] );
console.log ( "How are YOU?", Name2[2] );
console.log ( "How are YOU?", Name2[3] );
console.log ( "How are YOU?", Name2[4]);
// 13.Your Own Array: Think of your favorite mode of transportation, such as a motorcycle or a car, and make a list that stores several examples. Use your list to print a series of statements about these items, such as “I would like to own a Honda motorcycle.”
let transporteName: string[]=["corrolla","Marcedees", "Swift", "Frary", "Honda"];
console.log ( "I would like to drive?", transporteName[0] );
console.log ( "I would like to drive?", transporteName[1] );
console.log ( "I would like to drive?", transporteName[2] );
console.log ( "I would like to drive?", transporteName[3] );
console.log ( "I would like to drive?", transporteName[4] );

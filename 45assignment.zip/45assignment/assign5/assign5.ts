// 5 .Famous Quote 2: Repeat Exercise 4, but this time store the famous person’s name in a variable called famous_person. Then compose your message and store it in a new variable called message. Print your message.
let famous_Name1: string = "Quaid-e-Azam";
let message:string = "Determination brings the right prspective"
console.log (`${famous_Name1} said,${message}`);

// 5 .Famous Quote 2: Repeat Exercise 4, but this time store the famous person’s name in a variable called famous_person. Then compose your message and store it in a new variable called message. Print your message.
var famous_Name1 = "Quaid-e-Azam";
var message = "Determination brings the right prspective";
console.log("".concat(famous_Name1, " said,").concat(message));

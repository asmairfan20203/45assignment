// 9.Favorite Number: Store your favorite number in a variable. Then, using that variable, create a message that reveals your favorite number. Print that message.

let favnumber = 16;
console.log(`My age is sweet ${favnumber}, and i always be ${favnumber}`);
// 7.Number Eight: Write addition, subtraction, multiplication, and division operations that each result in the number 8. Be sure to enclose your operations in print statements to see the results.
let num1:number = 5,num2:number = 3;
let num3:number = 12,num4:number = 4;
let num5:number = 4,num6:number = 2;
let num7:number = 32,num8:number = 4;

console.log(num1+num2);
console.log(num3-num4);
console.log(num5*num6);
console.log(num7/num8);



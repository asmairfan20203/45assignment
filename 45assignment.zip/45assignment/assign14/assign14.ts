// 14 .Guest List: If you could invite anyone, living or deceased, to dinner, who would you invite? Make a list that includes at least three people you’d like to invite to dinner. Then use your list to print a message to each person, inviting them to dinner.

let GirlsName: string[]=["Tina","Mina", "Shina", "Sina", "Nina"];
console.log ( "I would like to invite you on birthday", GirlsName[0] );
console.log ( "I would like to invite you on birthday", GirlsName[1] );
console.log ( "I would like to invite you on birthday", GirlsName[2] );
console.log ( "I would like to invite you on birthday", GirlsName[3] );
console.log ( "I would like to invite you on birthday", GirlsName[4] );

"use strict";
// 4 .Famous Quote: Find a quote from a famous person you admire. Print the quote and the name of its author. Your output should look something like the following, including the quotation marks:
// Albert Einstein once said, “A person who never made a mistake never tried anything new.”
let Name2 = "Quaid-e-Azam";
console.log(`${Name2} said,"Determination brings the right prspective"`);
let famous_Name1 = "Quaid-e-Azam";
let message = "Determination brings the right prspective";
console.log(`${famous_Name1} said,${message}`);

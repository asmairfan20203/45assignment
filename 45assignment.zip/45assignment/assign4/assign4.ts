// 4 .Famous Quote: Find a quote from a famous person you admire. Print the quote and the name of its author. Your output should look something like the following, including the quotation marks:

// Albert Einstein once said, “A person who never made a mistake never tried anything new.”
let Name2: string = "Quaid-e-Azam";
console.log (`${Name2} said,"Determination brings the right prspective"`);




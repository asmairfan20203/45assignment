"use strict";
// 23. Conditional Tests: Write a series of conditional tests. Print a statement describing each test and your prediction for the results of each test. Your code should look something like this:
// let car = 'subaru';
// console.log("Is car == 'subaru'? I predict True.")
// console.log(car == 'subaru')
// • Look closely at your results, and make sure you understand why each line evaluates to True or False.
// • Create at least 10 tests. Have at least 5 tests evaluate to True and another 5 tests evaluate to False.
let car = "Marcedees";
console.log("Is car == 'Marcedees'? I predict True");
console.log(car == "Marcedees");
let Phon = "OppoA54";
console.log("Is Phon == 'OppoA54'? I predict True");
console.log(Phon == "OppoA54");
let laptop = "Hp";
console.log("Is laptop == 'Hp'? I predict True");
console.log(laptop == "Hp");
let watch = "Seiko5";
console.log("Is watch == 'Seiko5'? I predict True");
console.log(watch == "Seiko5");
let Pen = "Piano";
console.log("Is Pen == 'Piano'? I predict True");
console.log(Pen == "Piano");
let dress = "Khadi";
console.log("Is dress == 'Khadi'? I predict False");
console.log(dress == "Bareeze");
let Shoes = "Bata";
console.log("Is Shoes == 'Bata'? I predict False");
console.log(Shoes == "Service");
let Gold = "ARY";
console.log("Is Gold == 'ARY'? I predict False");
console.log(Gold == "Syed");
let Shampoo = "Pantene";
console.log("Is Shampoo == 'Sunsilk'? I predict False");
console.log(Shampoo == "Sunsilk");
let Soap = "Safeguard";
console.log("Is Soap == 'Safeguard'? I predict False");
console.log(Soap == "Lux");
